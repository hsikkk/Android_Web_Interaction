import './App.css';
import { useState } from 'react';
import useScript from './hooks/UseScript';

function App() {
  const [value, setValue] = useState("");
  const bridge = window.Bridge

  function onChangeText(e) {
    setValue(e.target.value);
  }


  function onSubmit(){
    bridge.setResult(
      (document.querySelector('.messageCheckbox:checked') != null ? document.querySelector('.messageCheckbox:checked').value : "none"),
      document.getElementById("text_text").value
    )
  }

  function clickBlue(){
    document.getElementById("check_blue").click()
  }

  function clickRed(){
    document.getElementById("check_red").click()
  }
  function setText(text){
    document.getElementById("text_text").value = text
  }

  useScript(clickBlue)
  useScript(clickRed)
  useScript(setText)

  return (
    <div className="Andorid Web View Interaction Test">
      <header className="App-header">
        <form method="get" action="form-action.html" onSubmit={onSubmit}>
          <h3>Test</h3>

          <p>
            Color
            <label>
              <input type="radio" id="check_blue" className="messageCheckbox" name="color" value="blue"/> 
              Blue
              </label>

            <label>
              <input type="radio" id="check_red" className="messageCheckbox" name="color" value="red"/> 
              Red
            </label>
          </p>
          
          <p>
            <label>Text </label>
            <input type="text" id="text_text" name="text" value={value} onChange={onChangeText}/>
          </p>
          
          <p>
            <input type="submit" id="btn_submit" value="Submit"/> 
            <input type="reset" id="btn_reset" value="Reset"/>
          </p>
          
        </form>
      </header>
    </div>
  );
}

export default App;
