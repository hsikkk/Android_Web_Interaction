import { useEffect } from "react";

const useScript = func => {
  useEffect(() => {
    const script = document.createElement('script');

    script.setAttribute("language", "JavaScript")
    script.innerHTML = func

    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    }
  }, [func]);
};

export default useScript;